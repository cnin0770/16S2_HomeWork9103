import java.util.ArrayList;

/**
 * Created by cnin0770 on 16/9/14.
 */
public class AccessList extends Customer {
    private ArrayList<Customer> accList= new ArrayList<>();

    public AccessList () {}

    //methods
    public void add (Customer newcustomer) {
        accList.add(newcustomer);
    }

    public void delete (int Id) {
        for (int i = 0; i < accList.size(); i++) {
            if (accList.get(i).getID() == Id) {
                accList.remove(i);
            }
        }
    }

    public boolean request () { return false;}

    public void query (int id) {
        Customer customer = new Customer();
        for (Customer k : accList) {
            if (k.getID() == id) {
                customer = k;
            }
        }
        ArrayList<Visit> visits = customer.getVisits();
    }
}
