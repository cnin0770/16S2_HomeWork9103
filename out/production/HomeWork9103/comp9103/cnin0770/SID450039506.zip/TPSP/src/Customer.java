import java.util.ArrayList;
import java.util.Date;

/**
 * Created by cnin0770 on 16/9/14.
 */
public class Customer extends Visit {
    //instance fields
    private int id;
    private String name;
    private double height;
    private Date DoB;
    private String address;
    private boolean superID;
    private ArrayList<Visit> visits;

    //constructor
    public Customer () {}

    public Customer (int I, String N, Date D) {
        id = I;
        name = N;
        DoB = D;
        superID = true;
    }

    public Customer (int I, String N, Date D, double H, String Ad) {
        id = I;
        name = N;
        DoB = D;
        height = H;
        address = Ad;
        superID = false;
    }

    //methods
    public int getID () {
        return id;
    }

    public ArrayList<Visit> getVisits () {
        return visits;
    }
}
