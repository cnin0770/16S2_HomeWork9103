import java.util.Date;

/**
 * Created by cnin0770 on 16/9/14.
 */
public class Visit {
    Date date;
    String attraction;

    public Visit () {}

    public Visit (String Att, Date D) {
        date = D;
        attraction = Att;
    }
}
