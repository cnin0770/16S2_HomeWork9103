//package comp9103.cnin0770;

/**
 Exercise 3: 1 st version of the necessary classes for your assignment
 Read your assignment specification and design the necessary classes to:
 a) Describe the data (instance fields/variables)
 b) Define the constructor(s)
 c) Outline the methods
 */
public class W6_HomeworkExercise3_ClassForAssignment {

}
